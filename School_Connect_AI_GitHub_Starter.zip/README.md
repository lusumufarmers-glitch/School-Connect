# School Connect App

A GitHub-ready school management and parent communication starter app.

## Features
- Institution registration and unique school code
- Institution admin login
- Parent/student login
- Fee balance and reminders
- Exam creation and results
- Paid exam catalogue (KES 50 example pricing)
- Paid lessons (KES 100 example pricing)
- Notification-ready dashboard
- AI Study Assistant UI for questions and JPG/PNG/PDF uploads
- Local demo data for testing

## Demo accounts
Institution:
- School code: DEMO001
- Username: admin
- Password: admin123

Parent:
- School code: DEMO001
- Admission number: ADM001
- Password: parent123

> Demo credentials are for development only. Replace authentication with a secure server-side system before production.

## Run
Open `index.html` in a browser, or serve the folder with any static web server.

For GitHub Pages, push the repository and enable Pages from the repository settings.

## AI Study Assistant
The starter includes the AI assistant interface and file-upload UI. It intentionally does not contain an AI API key. Connect the `Ask AI` action to a secure backend before production so credentials are not exposed in the browser.
