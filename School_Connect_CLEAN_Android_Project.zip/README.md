# School Connect Android

This repository is a clean Android Gradle project.

The APK builder must find these files at the repository root:
- settings.gradle
- build.gradle
- gradle.properties
- app/build.gradle
- app/src/main/AndroidManifest.xml

Demo:
School Code: DEMO001
Institution: admin / admin123
Parent: ADM001 / parent123

The AI and payment features are UI-ready starter features. Production AI/payment services must be connected through secure backends.
