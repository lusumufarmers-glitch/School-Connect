-- Production database starter schema.
CREATE TABLE institutions (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  school_code TEXT UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE students (
  id INTEGER PRIMARY KEY,
  institution_id INTEGER NOT NULL,
  admission_number TEXT NOT NULL,
  name TEXT NOT NULL,
  fee_balance INTEGER DEFAULT 0,
  FOREIGN KEY (institution_id) REFERENCES institutions(id),
  UNIQUE(institution_id, admission_number)
);

CREATE TABLE exams (
  id INTEGER PRIMARY KEY,
  institution_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  price_kes INTEGER DEFAULT 50,
  FOREIGN KEY (institution_id) REFERENCES institutions(id)
);

CREATE TABLE results (
  id INTEGER PRIMARY KEY,
  student_id INTEGER NOT NULL,
  exam_id INTEGER NOT NULL,
  score REAL,
  grade TEXT,
  FOREIGN KEY (student_id) REFERENCES students(id),
  FOREIGN KEY (exam_id) REFERENCES exams(id)
);

CREATE TABLE lessons (
  id INTEGER PRIMARY KEY,
  institution_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  price_kes INTEGER DEFAULT 100,
  content_url TEXT,
  FOREIGN KEY (institution_id) REFERENCES institutions(id)
);

CREATE TABLE payments (
  id INTEGER PRIMARY KEY,
  student_id INTEGER,
  amount_kes INTEGER NOT NULL,
  item_type TEXT NOT NULL,
  item_id INTEGER,
  status TEXT NOT NULL,
  provider_reference TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
