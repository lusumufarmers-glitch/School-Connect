# Damis School Connect Android

This is an actual Android Gradle project. The previous ZIP was a web/GitHub Pages project, so an Android APK builder correctly reported:

`ERROR: Android Gradle project was not found.`

This project fixes that by adding:
- Gradle Android project files
- AndroidManifest.xml
- Java MainActivity
- Android resources
- Web app bundled inside `app/src/main/assets/index.html`

## Demo
School Code: DEMO001
Institution: admin / admin123
Parent: ADM001 / parent123

## Build
Open the project in Android Studio or use a compatible Android/Gradle builder.
The output debug APK should be under:
`app/build/outputs/apk/debug/app-debug.apk`
