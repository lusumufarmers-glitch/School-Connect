# School Connect

GitHub-ready starter for a school management and parent communication app.

## Included
- Institution login using School Code
- Parent/student login using Admission Number
- Fee balance and reminders
- Exam results
- KES 50 exam catalogue
- KES 100 lessons
- AI Study Assistant interface
- JPG/PNG/PDF upload interface

## Demo
School Code: DEMO001
Institution: admin / admin123
Parent: ADM001 / parent123

## Important
The AI interface is a frontend starter. A real AI service must be connected through a secure backend so API keys are never exposed in browser code. Payment processing also needs an authorized payment provider.
