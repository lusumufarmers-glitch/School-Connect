const demo = {
  school: {
    code: "DEMO001",
    name: "Demo Academy",
    adminUsername: "admin",
    adminPassword: "admin123"
  },
  students: [
    { admission: "ADM001", name: "Demo Student", parentPassword: "parent123", feeBalance: 12500,
      results: [{ exam: "Term 2 Examination", score: 82, grade: "A" }] }
  ],
  exams: [
    { id: 1, title: "Mathematics Revision Exam", price: 50 },
    { id: 2, title: "English Revision Exam", price: 50 }
  ],
  lessons: [
    { id: 1, title: "Mathematics: Fractions", price: 100 },
    { id: 2, title: "English: Grammar", price: 100 }
  ],
  notifications: [
    "Fee reminder: please check the current outstanding balance.",
    "Term 2 examination results are now available."
  ]
};

const $ = id => document.getElementById(id);

$("role").addEventListener("change", () => {
  const institution = $("role").value === "institution";
  $("parentFields").classList.toggle("hidden", institution);
  $("institutionFields").classList.toggle("hidden", !institution);
});

$("loginBtn").addEventListener("click", () => {
  const code = $("schoolCode").value.trim().toUpperCase();
  $("loginMessage").textContent = "";

  if (code !== demo.school.code) {
    $("loginMessage").textContent = "School code not found.";
    return;
  }

  if ($("role").value === "institution") {
    if ($("adminUsername").value === demo.school.adminUsername &&
        $("adminPassword").value === demo.school.adminPassword) {
      showInstitution();
    } else $("loginMessage").textContent = "Invalid institution login.";
  } else {
    const student = demo.students.find(s =>
      s.admission === $("admission").value.trim() &&
      s.parentPassword === $("parentPassword").value
    );
    if (student) showParent(student);
    else $("loginMessage").textContent = "Invalid admission number or password.";
  }
});

function showParent(student) {
  $("loginView").classList.add("hidden");
  $("parentView").classList.remove("hidden");
  $("institutionView").classList.add("hidden");
  $("logoutBtn").classList.remove("hidden");

  $("parentWelcome").textContent = `Welcome, ${student.name}`;
  $("parentSchool").textContent = demo.school.name;
  $("feeBalance").textContent = `KES ${student.feeBalance.toLocaleString()}`;
  $("feeReminder").textContent = student.feeBalance > 0
    ? "Fee reminder: your account has an outstanding balance."
    : "Fees are fully paid.";
  const r = student.results[student.results.length - 1];
  $("latestResult").textContent = r ? `${r.exam}: ${r.score}% (${r.grade})` : "No result yet.";

  $("examList").innerHTML = demo.exams.map(e => `
    <div class="item"><strong>${e.title}</strong><br>KES ${e.price}
    <button onclick="buyExam(${e.id})">Buy exam</button></div>`).join("");

  $("lessonList").innerHTML = demo.lessons.map(l => `
    <div class="item"><strong>${l.title}</strong><br>KES ${l.price}
    <button onclick="buyLesson(${l.id})">Buy lesson</button></div>`).join("");

  $("notifications").innerHTML = demo.notifications.map(n => `<div class="item">${n}</div>`).join("");
}

function showInstitution() {
  $("loginView").classList.add("hidden");
  $("parentView").classList.add("hidden");
  $("institutionView").classList.remove("hidden");
  $("logoutBtn").classList.remove("hidden");
  renderInstitution();
}

function renderInstitution() {
  $("institutionCode").textContent = demo.school.code;
  $("studentCount").textContent = demo.students.length;
  $("outstandingFees").textContent =
    `KES ${demo.students.reduce((sum, s) => sum + s.feeBalance, 0).toLocaleString()}`;

  $("studentTable").innerHTML = `
    <table><thead><tr><th>Admission</th><th>Student</th><th>Balance</th><th>Latest result</th></tr></thead>
    <tbody>${demo.students.map(s => {
      const r = s.results[s.results.length - 1];
      return `<tr><td>${s.admission}</td><td>${s.name}</td><td>KES ${s.feeBalance.toLocaleString()}</td>
      <td>${r ? `${r.score}% (${r.grade})` : "-"}</td></tr>`;
    }).join("")}</tbody></table>`;
}

$("saveResultBtn").addEventListener("click", () => {
  const student = demo.students.find(s => s.admission === $("resultAdmission").value.trim());
  if (!student) {
    $("resultMessage").textContent = "Student not found.";
    return;
  }
  student.results.push({
    exam: $("examName").value.trim() || "New Examination",
    score: Number($("score").value),
    grade: $("grade").value.trim() || "-"
  });
  $("resultMessage").textContent = "Result saved in the demo database.";
  $("resultMessage").className = "message success";
  renderInstitution();
});

function buyExam(id) {
  const exam = demo.exams.find(e => e.id === id);
  alert(`Exam selected: ${exam.title}. Payment integration will be connected in the production version.`);
}

function buyLesson(id) {
  const lesson = demo.lessons.find(l => l.id === id);
  alert(`Lesson selected: ${lesson.title}. Payment integration will be connected in the production version.`);
}

$("logoutBtn").addEventListener("click", () => {
  $("loginView").classList.remove("hidden");
  $("parentView").classList.add("hidden");
  $("institutionView").classList.add("hidden");
  $("logoutBtn").classList.add("hidden");
});

function openAI() {
  $("loginView").classList.add("hidden");
  $("parentView").classList.add("hidden");
  $("institutionView").classList.add("hidden");
  $("aiView").classList.remove("hidden");
  $("logoutBtn").classList.remove("hidden");
}

$("askAiBtn").addEventListener("click", () => {
  const question = $("aiQuestion").value.trim();
  const file = $("aiFile").files[0];

  if (!question && !file) {
    $("aiMessage").textContent = "Enter a question or upload a JPG, PNG or PDF.";
    return;
  }

  const fileText = file ? `I received your file: ${file.name}. ` : "";
  $("aiMessage").textContent = "";
  $("aiAnswer").innerHTML =
    `<strong>Demo AI response</strong><br><br>${fileText}` +
    `This starter project is ready for connection to a secure AI backend. ` +
    `The production AI can read supported images/PDFs, understand the question, ` +
    `and provide a step-by-step educational explanation.`;
});

const originalLogout = $("logoutBtn").onclick;
$("logoutBtn").addEventListener("click", () => {
  $("aiView").classList.add("hidden");
});
